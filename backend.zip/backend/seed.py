from sqlalchemy.orm import Session
from database import SessionLocal
from models import User, NEPCourse, FacultySchedule
from utils import hash_password


# Full period time map
PERIOD_TIMES = {
    "P1": ("09:00", "09:50"),
    "P2": ("10:00", "10:50"),
    "P3": ("11:00", "11:50"),
    "P4": ("12:00", "12:50"),
    "P5": ("13:30", "14:20"),
    "P6": ("14:30", "15:20"),
}

ALL_PERIODS = ["P1", "P2", "P3", "P4", "P5", "P6"]


def seed_data():
    db: Session = SessionLocal()

    if db.query(User).filter(User.role == "admin").first():
        db.close()
        return

    # ── Admin ──────────────────────────────────────────
    admin = User(
        name="Admin", email="admin@smartcampus.com",
        password=hash_password("admin123"), role="admin",
        department="CSE(AI&DS)", is_approved=True
    )
    db.add(admin)

    # ── Faculty ────────────────────────────────────────
    faculty_ids = []
    for i in range(1, 7):
        f = User(
            name=f"Faculty {i}",
            email=f"faculty{i}@smartcampus.com",
            password=hash_password(f"fac{i}123"),
            role="faculty", department="CSE(AI&DS)", is_approved=True
        )
        db.add(f)
        db.flush()
        faculty_ids.append(f.id)

    db.commit()

    fid = faculty_ids[0]   # Faculty 1 gets a rich Monday schedule

    # ── Faculty 1 — Monday (day 0) ────────────────────
    # Periods: P1 P2 (theory), P3 P4 (FREE), P5 P6 (lab)
    monday_classes = [
        ("P1", "SUBJ001", "Data Structures",         "AI-1A", "10", "theory"),
        ("P2", "SUBJ002", "Design & Analysis",        "AI-1A", "11", "theory"),
        # P3, P4 are FREE — not inserted (absence = free period)
        ("P5", "SUBJ003", "DS Lab",                  "AI-1A", "14", "lab"),
        ("P6", "SUBJ004", "Algorithm Lab",            "AI-1A", "15", "lab"),
    ]

    for period, code, subject, section, room, ctype in monday_classes:
        start, end = PERIOD_TIMES[period]
        db.add(FacultySchedule(
            faculty_id=fid, day_of_week=0, period=period,
            subject=subject, subject_code=code, section=section,
            class_type=ctype, room_no=room,
            start_time=start, end_time=end
        ))

    # ── Faculty 1 — Tuesday (day 1) ────────────────────
    tuesday_classes = [
        ("P1", "SUBJ001", "Data Structures",   "AI-1A", "10", "theory"),
        ("P3", "SUBJ005", "Machine Learning",  "AI-1B", "12", "theory"),
        ("P4", "SUBJ005", "Machine Learning",  "AI-1B", "12", "theory"),
        ("P6", "SUBJ003", "DS Lab",            "AI-1A", "14", "lab"),
    ]

    for period, code, subject, section, room, ctype in tuesday_classes:
        start, end = PERIOD_TIMES[period]
        db.add(FacultySchedule(
            faculty_id=fid, day_of_week=1, period=period,
            subject=subject, subject_code=code, section=section,
            class_type=ctype, room_no=room,
            start_time=start, end_time=end
        ))

    # ── Other Faculty — basic 1 period each day ────────
    for idx, fac_id in enumerate(faculty_ids[1:], start=1):
        period = "P1"
        start, end = PERIOD_TIMES[period]
        db.add(FacultySchedule(
            faculty_id=fac_id, day_of_week=idx, period=period,
            subject="Data Structures", subject_code=f"SUBJ00{idx+1}",
            section="AI-1A", class_type="theory",
            room_no=f"AI-{101 + idx}",
            start_time=start, end_time=end
        ))

    # ── NEP Courses ────────────────────────────────────
    if not db.query(NEPCourse).first():
        courses = [
            NEPCourse(title="Introduction to Machine Learning",
                      category="AI", skill_tag="Artificial Intelligence", duration="6 weeks"),
            NEPCourse(title="Full Stack Web Development",
                      category="Web", skill_tag="Web Development", duration="8 weeks"),
            NEPCourse(title="Data Science with Python",
                      category="Data", skill_tag="Data Science", duration="6 weeks"),
            NEPCourse(title="Cloud Computing Fundamentals",
                      category="Cloud", skill_tag="Cloud Computing", duration="4 weeks"),
            NEPCourse(title="Deep Learning & Neural Networks",
                      category="AI", skill_tag="Deep Learning Artificial Intelligence", duration="8 weeks"),
            NEPCourse(title="React & Modern Frontend",
                      category="Web", skill_tag="Web Development React", duration="5 weeks"),
        ]
        db.add_all(courses)

    db.commit()
    db.close()