import { useEffect, useState } from "react"
import MainLayout from "../../layouts/MainLayout"
import { getProfile, updateInterests, getRecommendations } from "../../services/api"

// Suggested interest tags students can click to add
const SUGGESTED_TAGS = [
  "AI", "Machine Learning", "Deep Learning", "Computer Vision", "NLP",
  "Data Science", "Python", "Web Development", "React", "Node.js",
  "Full Stack", "Cloud", "AWS", "DevOps", "Docker", "Kubernetes",
  "Cybersecurity", "Ethical Hacking", "Android", "Flutter",
  "IoT", "Blockchain", "SQL", "MongoDB", "Java", "C++",
  "UI/UX", "Figma", "Competitive Programming", "Algorithms",
  "Entrepreneurship", "Digital Marketing", "Product Management",
  "Data Visualisation", "Tableau", "Generative AI", "LLM",
]

const CATEGORY_COLORS = {
  AI:           "bg-purple-100 text-purple-700 border-purple-200",
  Data:         "bg-green-100 text-green-700 border-green-200",
  Web:          "bg-blue-100 text-blue-700 border-blue-200",
  Cloud:        "bg-sky-100 text-sky-700 border-sky-200",
  Security:     "bg-red-100 text-red-700 border-red-200",
  Mobile:       "bg-orange-100 text-orange-700 border-orange-200",
  IoT:          "bg-teal-100 text-teal-700 border-teal-200",
  Database:     "bg-yellow-100 text-yellow-700 border-yellow-200",
  Programming:  "bg-indigo-100 text-indigo-700 border-indigo-200",
  Design:       "bg-pink-100 text-pink-700 border-pink-200",
  Business:     "bg-amber-100 text-amber-700 border-amber-200",
  "Soft Skills":"bg-lime-100 text-lime-700 border-lime-200",
  Blockchain:   "bg-violet-100 text-violet-700 border-violet-200",
  "Emerging Tech": "bg-cyan-100 text-cyan-700 border-cyan-200",
}

export default function StudentSkills() {
  const [profile,   setProfile]   = useState(null)
  const [interests, setInterests] = useState("")
  const [preview,   setPreview]   = useState([])  // top matched courses
  const [saving,    setSaving]    = useState(false)
  const [saved,     setSaved]     = useState(false)
  const [error,     setError]     = useState("")
  const [loading,   setLoading]   = useState(true)

  useEffect(() => {
    Promise.all([getProfile(), getRecommendations()])
      .then(([prof, recs]) => {
        setProfile(prof)
        setInterests(prof.interests || "")
        setPreview(recs.slice(0, 6))
      })
      .catch(() => setError("Could not load profile"))
      .finally(() => setLoading(false))
  }, [])

  // Live preview: re-score whenever interests change
  useEffect(() => {
    if (!interests.trim()) { setPreview([]); return }

    const interestWords = new Set(
      interests.toLowerCase().replace(/,/g, " ").split(" ").filter(w => w.length > 2)
    )

    const score = (course) => {
      const tagWords   = new Set(course.skill_tag.toLowerCase().replace(/[,-]/g, " ").split(" "))
      const titleWords = new Set(course.title.toLowerCase().split(" "))
      const tagHits    = [...interestWords].reduce((s, w) => s + (tagWords.has(w) ? 2 : 0), 0)
      const titleHits  = [...interestWords].reduce((s, w) => s + (titleWords.has(w) ? 1 : 0), 0)
      const partial    = [...interestWords].reduce((s, iw) =>
        s + [...tagWords].filter(tw => tw.includes(iw) || iw.includes(tw)).length, 0)
      return tagHits + titleHits + partial
    }

    // We need the full course list for live scoring; store it
    getRecommendations().then(all => {
      const scored = [...all].sort((a, b) => score(b) - score(a))
      setPreview(scored.slice(0, 6))
    })
  }, [interests])

  const addTag = (tag) => {
    const current = interests.split(",").map(s => s.trim()).filter(Boolean)
    if (!current.map(s => s.toLowerCase()).includes(tag.toLowerCase())) {
      setInterests([...current, tag].join(", "))
    }
  }

  const removeTag = (tag) => {
    const updated = interests.split(",")
      .map(s => s.trim())
      .filter(s => s.toLowerCase() !== tag.toLowerCase())
    setInterests(updated.join(", "))
  }

  const currentTags = interests.split(",").map(s => s.trim()).filter(Boolean)

  const handleSave = async () => {
    if (!interests.trim()) return setError("Please enter at least one interest")
    setSaving(true)
    setError("")
    setSaved(false)
    try {
      await updateInterests(interests)
      setSaved(true)
      setTimeout(() => setSaved(false), 3000)
    } catch (e) {
      setError(e.message || "Failed to save")
    } finally {
      setSaving(false)
    }
  }

  if (loading) {
    return (
      <MainLayout>
        <div className="mt-10 text-center text-gray-400 animate-pulse">Loading profile...</div>
      </MainLayout>
    )
  }

  return (
    <MainLayout>
      <div className="mt-6 max-w-4xl">

        <h2 className="text-2xl font-bold text-gray-800 mb-1">Skills & Interests</h2>
        <p className="text-gray-500 text-sm mb-8">
          Update your interests to get personalised NEP course recommendations.
        </p>

        <div className="grid md:grid-cols-2 gap-6">

          {/* ── Left: Edit Panel ── */}
          <div className="space-y-5">

            {/* Profile card */}
            <div className="bg-white rounded-2xl shadow-sm border p-5 flex items-center gap-4">
              <div className="w-12 h-12 rounded-full bg-blue-600 text-white flex items-center justify-center text-xl font-bold">
                {profile?.name?.[0] ?? "S"}
              </div>
              <div>
                <p className="font-semibold text-gray-800">{profile?.name}</p>
                <p className="text-sm text-gray-400">{profile?.department} · {profile?.email}</p>
              </div>
            </div>

            {/* Current tags */}
            <div className="bg-white rounded-2xl shadow-sm border p-5">
              <p className="text-sm font-semibold text-gray-700 mb-3">Your Current Interests</p>
              {currentTags.length === 0 ? (
                <p className="text-gray-400 text-sm">No interests added yet. Pick from suggestions below.</p>
              ) : (
                <div className="flex flex-wrap gap-2">
                  {currentTags.map(tag => (
                    <span
                      key={tag}
                      className="flex items-center gap-1 px-3 py-1 bg-blue-50 border border-blue-200 text-blue-700 rounded-full text-sm font-medium"
                    >
                      {tag}
                      <button
                        onClick={() => removeTag(tag)}
                        className="ml-1 text-blue-400 hover:text-red-500 transition text-xs font-bold"
                      >
                        ✕
                      </button>
                    </span>
                  ))}
                </div>
              )}
            </div>

            {/* Free-text input */}
            <div className="bg-white rounded-2xl shadow-sm border p-5">
              <label className="text-sm font-semibold text-gray-700 block mb-2">
                Edit Interests (comma-separated)
              </label>
              <textarea
                value={interests}
                onChange={e => setInterests(e.target.value)}
                rows={3}
                placeholder="e.g. Machine Learning, Python, Web Development, Cloud"
                className="w-full border rounded-xl p-3 text-sm outline-none focus:border-blue-400 resize-none transition"
              />
              <p className="text-xs text-gray-400 mt-1">
                Separate interests with commas. You can also click suggestions below.
              </p>
            </div>

            {/* Suggested tags */}
            <div className="bg-white rounded-2xl shadow-sm border p-5">
              <p className="text-sm font-semibold text-gray-700 mb-3">💡 Quick Add Suggestions</p>
              <div className="flex flex-wrap gap-2">
                {SUGGESTED_TAGS.map(tag => {
                  const added = currentTags.map(s => s.toLowerCase()).includes(tag.toLowerCase())
                  return (
                    <button
                      key={tag}
                      onClick={() => added ? removeTag(tag) : addTag(tag)}
                      className={`px-3 py-1 rounded-full text-xs font-medium border transition ${
                        added
                          ? "bg-blue-600 text-white border-blue-600"
                          : "bg-gray-50 text-gray-600 border-gray-200 hover:border-blue-400 hover:text-blue-600"
                      }`}
                    >
                      {added ? "✓ " : "+ "}{tag}
                    </button>
                  )
                })}
              </div>
            </div>

            {error && <p className="text-red-500 text-sm">{error}</p>}

            <button
              onClick={handleSave}
              disabled={saving}
              className={`w-full py-3 rounded-xl font-semibold transition text-white ${
                saving ? "bg-gray-400 cursor-not-allowed"
                : saved  ? "bg-green-600"
                : "bg-blue-600 hover:bg-blue-700"
              }`}
            >
              {saving ? "Saving..." : saved ? "✅ Saved!" : "Save Interests"}
            </button>

          </div>

          {/* ── Right: Live Preview ── */}
          <div>
            <div className="bg-white rounded-2xl shadow-sm border p-5">
              <p className="text-sm font-semibold text-gray-700 mb-1">
                🎯 Live Recommendation Preview
              </p>
              <p className="text-xs text-gray-400 mb-4">
                Updates as you change your interests
              </p>

              {preview.length === 0 ? (
                <div className="text-center py-10 text-gray-400">
                  <p className="text-3xl mb-2">🎓</p>
                  <p className="text-sm">Add interests to see matched courses</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {preview.map((course, i) => {
                    const colorClass = CATEGORY_COLORS[course.category] || "bg-gray-100 text-gray-700 border-gray-200"
                    return (
                      <div key={course.id}
                        className="flex items-start gap-3 p-3 rounded-xl border hover:shadow-sm transition"
                      >
                        <span className="text-gray-300 font-bold text-sm w-5 shrink-0 mt-0.5">
                          {i + 1}
                        </span>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-semibold text-gray-800 leading-snug truncate">
                            {course.title}
                          </p>
                          <p className="text-xs text-gray-400 mt-0.5">⏱ {course.duration}</p>
                        </div>
                        <span className={`text-xs px-2 py-0.5 rounded-full border font-medium shrink-0 ${colorClass}`}>
                          {course.category}
                        </span>
                      </div>
                    )
                  })}
                  <p className="text-xs text-center text-gray-400 pt-2">
                    Save to apply • Full list in NEP Programs
                  </p>
                </div>
              )}
            </div>
          </div>

        </div>
      </div>
    </MainLayout>
  )
}